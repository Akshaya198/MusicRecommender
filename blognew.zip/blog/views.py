# Create your views here.
from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout

from django.core.paginator import Paginator
from . models import Song

# ml 
import pandas as pd
import numpy as np
'''
def knnQuery(queryPoint, arrCharactPoints, k):
    tmp = arrCharactPoints.copy(deep=True)
    tmp['dist'] = tmp.apply(lambda x: np.linalg.norm(x-queryPoint), axis=1)
    tmp = tmp.sort_values('dist')
    return tmp.head(k).index

def querySimilars(df, columns, idx, func, param):
    arr = df[columns].copy(deep=True)
    queryPoint = arr.loc[idx]
    arr = arr.drop([idx])
    response = func(queryPoint, arr, param)
    return response

def getMusicName(elem):
    return '{} - {}'.format(elem['artist_name'], elem['track_name'])

def actualprog(x,y):   
    song_data=pd.read_csv('C:/Users/Akshaya Lakshmi/dj/blog/SpotifyFeatures.csv')
    song_data.sort_values('track_name')
    song_data.duplicated('track_name')
    ss=song_data
    ssclean=ss.drop_duplicates(subset='track_name')
    ssclean=ssclean.sort_values('track_name')
    spop=ssclean.sort_values('popularity')
    a=[]
    row_num = spop[(spop['track_name'] == y) & (spop['artist_name'] == x)].index.to_numpy() 
    songIndex = row_num[0] # query point, selected song
    columns = ['acousticness','danceability','energy','instrumentalness','liveness','speechiness','valence']
    # Selecting query parameters
    func, param = knnQuery, 3 # k=3
    # Querying
    response = querySimilars(spop, columns, songIndex, func, param)
    anySong = spop.loc[songIndex]
    # Get the song name
    anySongName = getMusicName(anySong)
    # Print
    #print('#Query Point')
    #print(songIndex, anySongName)
    #print('# Similar songs')
    for idx in response:
        anySong = spop.loc[idx]
        anySongName = getMusicName(anySong)
        a.append(anySongName)
    return a
'''

song_data=pd.read_csv('C:/Users/Akshaya Lakshmi/dj/blog/SpotifyFeatures.csv')
song_data.sort_values('track_name')
song_data.duplicated('track_name')
ss=song_data
ssclean=ss.drop_duplicates(subset='track_name')
ssclean=ssclean.sort_values('track_name')
spop=ssclean.sort_values('popularity')
def knnQuery(queryPoint, arrCharactPoints, k):
    tmp = arrCharactPoints.copy(deep=True)
    tmp['dist'] = tmp.apply(lambda x: np.linalg.norm(x-queryPoint), axis=1)
    tmp = tmp.sort_values('dist')
    return tmp.head(k).index
def querySimilars(df, columns, idx, func, param):
    arr = df[columns].copy(deep=True)
    queryPoint = arr.loc[idx]
    arr = arr.drop([idx])
    response = func(queryPoint, arr, param)
    return response
def getMusicName(elem):
    return '{} - {}'.format(elem['artist_name'], elem['track_name'])
def pr(x,y,spop):
    h=[]
    row_num = spop[(spop['track_name'] ==x ) & (spop['artist_name'] ==y)].index.to_numpy() 
    songIndex = row_num[0] # query point, selected song
    columns = ['acousticness','danceability','energy','instrumentalness','liveness','speechiness','valence']
    func, param = knnQuery, 3 # k=3
    response = querySimilars(spop, columns, songIndex, func, param)
    anySong = spop.loc[songIndex]
    anySongName = getMusicName(anySong)
    print('#Query Point')
    print(songIndex, anySongName)
    print('# Similar songs')
    for idx in response:
        anySong = spop.loc[idx]
        anySongName = getMusicName(anySong)
        h.append(anySongName)
    return h
# ml done

def signup(request):
  if request.method == "POST":
    first_name = request.POST['first-name']
    last_name = request.POST['last-name']
    username = request.POST['username']
    password = request.POST['password']
    confpassword = request.POST['confirm-password']
    email = request.POST['email']

    myuser=User.objects.create_user(username,email,password)
    myuser.first_name= first_name
    myuser.last_name=last_name
    myuser.save()
    messages.success(request, 'Your account has been created successfully.')
    return redirect('signin')

  return render(request, "blog/signup.html")

def signin(request):
  if request.method == 'POST':
    username = request.POST['username']
    password = request.POST['password']
    user = authenticate(username=username, password=password)
    if user is not None:
      login(request, user)
      fname= user.first_name
      return render(request, "blog/home.html", {'fname': fname})
    else:
      messages.error(request, "Bad credentials")
      return redirect('/')

  return render(request, "blog/signin.html")

def signout(request):
  logout(request)
  return render(request, "blog/signout.html")

def firstpage(request):
  return render(request, "blog/firstpage.html")

def home(request): 
  if request.method== 'POST':
    artist = request.POST['artist']
    music = request.POST['music']
    song_data=pd.read_csv('C:/Users/Akshaya Lakshmi/dj/blog/SpotifyFeatures.csv')
    song_data.sort_values('track_name')
    song_data.duplicated('track_name')
    ss=song_data
    ssclean=ss.drop_duplicates(subset='track_name')
    ssclean=ssclean.sort_values('track_name')
    spop=ssclean.sort_values('popularity')
    y=pr(artist,music,spop)
    return render(request, "blog/recommend.html", {'fname1': y[0],'fname2': y[1],'fname3': y[2],'fnamea': artist,'fnamem': music})
    #return render(request, "blog/recommend.html",{'fnamea': artist,'fnamem': music})
  return render(request, "blog/home.html")

def popular(request):
  paginator= Paginator(Song.objects.all(),1)
  page_number = request.GET.get('page')
  page_obj = paginator.get_page(page_number)
  context={"page_obj":page_obj}
  return render(request,"blog/popular.html",context)

def recommend(request):
   return render(request, "blog/recommend.html")



#return render(request, "blog/popular.html")