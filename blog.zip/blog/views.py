# Create your views here.
from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout

from django.core.paginator import Paginator
from . models import Song

def home(request): 
  return render(request, "blog/home.html")

def signup(request):
  if request.method == "POST":
    first_name = request.POST['first-name']
    last_name = request.POST['last-name']
    username = request.POST['username']
    password = request.POST['password']
    confpassword = request.POST['confirm-password']
    email = request.POST['email']

    myuser=User.objects.create_user(username,email,password)
    myuser.first_name= first_name
    myuser.last_name=last_name
    myuser.save()
    messages.success(request, 'Your account has been created successfully.')
    return redirect('signin')

  return render(request, "blog/signup.html")

def signin(request):
  if request.method == 'POST':
    username = request.POST['username']
    password = request.POST['password']
    user = authenticate(username=username, password=password)
    if user is not None:
      login(request, user)
      fname= user.first_name
      return render(request, "blog/home.html", {'fname': fname})
    else:
      messages.error(request, "Bad credentials")
      return redirect('/')

  return render(request, "blog/signin.html")

def signout(request):
  logout(request)
  return render(request, "blog/signout.html")

def firstpage(request):
  return render(request, "blog/firstpage.html")

def popular(request):
  paginator= Paginator(Song.objects.all(),1)
  page_number = request.GET.get('page')
  page_obj = paginator.get_page(page_number)
  context={"page_obj":page_obj}
  return render(request,"blog/popular.html",context)


# return render(request, "blog/popular.html")