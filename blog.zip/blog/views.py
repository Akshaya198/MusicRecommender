# Create your views here.
from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout

from django.core.paginator import Paginator
from . models import Song,History

# ml 
import pandas as pd
import numpy as np
from .mm import model_,pop

def getsuggestions(artist,music):
  x=model_(artist,music)
  return x

def signup(request):
  if request.method == "POST":
    first_name = request.POST['first-name']
    last_name = request.POST['last-name']
    username = request.POST['username']
    password = request.POST['password']
    confpassword = request.POST['confirm-password']
    email = request.POST['email']

    myuser=User.objects.create_user(username,email,password)
    myuser.first_name= first_name
    myuser.last_name=last_name
    myuser.save()
    messages.success(request, 'Your account has been created successfully.')
    return redirect('signin')

  return render(request, "blog/signup.html")

def signin(request):
  if request.method == 'POST':
    username = request.POST['username']
    password = request.POST['password']
    user = authenticate(username=username, password=password)
    if user is not None:
      login(request, user)
      fname= user.first_name
      results=Song.objects.all()
      return render(request, "blog/home.html", {'fname': fname,"results":results})
    else:
      messages.error(request, "Bad credentials")
      return redirect('/')

  return render(request, "blog/signin.html")

def signout(request):
  logout(request)
  return render(request, "blog/signout.html")

def firstpage(request):
  return render(request, "blog/firstpage.html")

def home(request): 
  if request.method== 'POST':
    artist = request.POST['artist']
    music = request.POST['music']
    m = History(usern=request.user.username, s_artist=artist, s_title=music)
    m.save()
    y = getsuggestions(artist, music)
    k=Song.objects.all()
    x=[]
    for i in y:
      l=i.split('-')
      x.append(l[1].strip())
    return render(request, "blog/recommend.html", {'fname1': y[0],'fname2': y[1],'fname3': y[2],'fnamea': artist,'fnamem': music,'x':x,'k':k})
  results=Song.objects.all()
  return render(request, "blog/home.html",{"fname":request.user.username,"results":results})

def popular(request):
  p=[]
  s=Song.objects.all()
  for i in s:
    t=pop(i.artist,i.title)
    p.append(t)
  print(p)
  s=list(s)
  for i in range(0,len(s)):
    for j in range(0,len(s)-1):
      if(p[j]<p[j+1]):
        p[j],p[j+1]=p[j+1],p[j]
        s[j],s[j+1]=s[j+1],s[j]
  s=s[0:8]
  #paginator= Paginator(Song.objects.all(),1)
  paginator= Paginator(s,1)
  page_number = request.GET.get('page')
  page_obj = paginator.get_page(page_number)
  context={"page_obj":page_obj}
  return render(request,"blog/popular.html",context)

def recommend(request):
   return render(request, "blog/recommend.html")

def foryou(request):
  l,z,x,o=([] for i in range(0,4))
  htry=History.objects.filter(usern=request.user)
  for i in htry:
    z.append(Song.objects.get( title=i.s_title))
  l=z[0:2]
  for i in l:
    h=[]
    s=i.title
    k=i.artist
    p=getsuggestions(k,s)
    for j in p:
      t=j.split('-')
      h.append(t[1].strip())
    h=h[1:3]
    print(h)
    for j in h:
      x.append(j)
  print(x)
  for i in x:
    try:
      o.append(Song.objects.get(title=i))
    except Song.DoesNotExist:
      continue
  return render(request, "blog/foryou.html", {'k':z,'o':o})
