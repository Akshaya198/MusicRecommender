from django.contrib import admin
from . models import Song,History

# Register your models here.
admin.site.register(Song)
admin.site.register(History)